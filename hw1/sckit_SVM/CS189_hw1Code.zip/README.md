## Instructions on running hw1_code.ipynb:

Dependency requirements are in requirements.txt. Please use pip install -r requirements.txt

### NOTE: The .mat files and spam/ham text files for the datasets are not included. Please ensure that these
datasets are included to properly run the HW1 code. Place the data in a folder called data/ in the same directory
as hw1_code.ipynb. 

Use Jupyter Notebook to open hw1_code.ipynb and proceed to run cells sequentially as needed. 
